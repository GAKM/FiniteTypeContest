from otree.api import *
import random
import time
from datetime import datetime
import string

doc = """
Your app description
"""


class C(BaseConstants):
    NAME_IN_URL = 'Debrief'
    PLAYERS_PER_GROUP = None
    NUM_ROUNDS = 1


class Subsession(BaseSubsession):
    pass


class Group(BaseGroup):
    pass


class Player(BasePlayer):
    experiment_end_time = models.LongStringField()
    completion_code = models.StringField()
    final_bonus_USD = models.CurrencyField()
    total_payoff_USD = models.FloatField()


# PAGES
class Earnings(Page):
    def vars_for_template(player:Player):
        participant = player.participant
        session = player.session
        player.final_bonus_USD = player.participant.contest_earnings.to_real_world_currency(session)
        total_payoff_USD = participant.payoff_plus_participation_fee()
    
        player.experiment_end_time = datetime.now().strftime("%H:%M:%S")        
        characters = string.ascii_letters + string.digits
        player.completion_code = "SSEL_" + ''.join(random.choices(characters, k=10))

        return dict(
            total_bonus = player.final_bonus_USD,
            total_earnings_in_USD = participant.payoff_plus_participation_fee(),
            code = player.completion_code)        




page_sequence = [Earnings]
