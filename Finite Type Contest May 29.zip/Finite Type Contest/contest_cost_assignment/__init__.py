from otree.api import (
    models, widgets, BaseConstants, BaseSubsession, BaseGroup, BasePlayer, Page, Currency as c, currency_range, WaitPage
)
import random

doc = """
Your app description
"""


class C(BaseConstants):
    NAME_IN_URL = 'ContestCostAssignment'
    PLAYERS_PER_GROUP = None
    NUM_ROUNDS = 1
    ENDOWMENT = 200
    COST_HIGH = 2
    COST_LOW = 1

class Subsession(BaseSubsession):
    pass

class Group(BaseGroup):
	pass

class Player(BasePlayer):
    COST = models.IntegerField()


# FUNCTIONS

def creating_session(self): # Assigning costs

    for p in self.get_players():
            COST = random.choice([C.COST_HIGH, C.COST_LOW])
            p.COST = COST
            participant = p.participant
            participant.COST = p.COST


# PAGES

class Cost_Assignment(Page):
    pass



page_sequence = [Cost_Assignment]
