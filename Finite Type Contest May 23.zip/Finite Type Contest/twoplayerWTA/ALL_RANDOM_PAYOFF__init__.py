from otree.api import (
    models, widgets, BaseConstants, BaseSubsession, BaseGroup, BasePlayer, Page, Currency as c, currency_range, WaitPage
)
import random

doc = """
2 Player Finite-Type Contest Game
"""


class C(BaseConstants):
    NAME_IN_URL = 'TwoPlayerWTA'
    PLAYERS_PER_GROUP = 2
    NUM_ROUNDS = 10
    ENDOWMENT = 200
    COST_HIGH = 2
    COST_LOW = 1
    TWO_PLAYER_PRIZE = 100

class Subsession(BaseSubsession):
    pass

def creating_session(subsession: Subsession):
    session = subsession.session    

class Group(BaseGroup):
    winning_bid = models.FloatField()


class Player(BasePlayer):

    bid = models.FloatField(
        min=0, max=C.ENDOWMENT, label="How much do you want to bid?"
    )

    is_winner = models.BooleanField()

    final_payoff = models.CurrencyField()

    final_payoff_round = models.IntegerField()


# FUNCTIONS

def set_payoffs(group: Group):

    players = group.get_players()
    group.winning_bid = max([p.bid for p in players])
    winners = [p for p in players if p.bid == group.winning_bid]
    winner = random.choice(winners)
    for p in players:
        if p == winner:
            p.is_winner = True
            p.payoff = C.ENDOWMENT + C.TWO_PLAYER_PRIZE - p.bid * p.participant.COST
        else:
            p.is_winner = False
            p.payoff = C.ENDOWMENT - p.bid * p.participant.COST

def other_player(player: Player):
    return player.get_others_in_group()[0]    


# PAGES

class PairingWaitPage(WaitPage):
    group_by_arrival_time = True

    @staticmethod
    def is_displayed(player):
        return player.round_number == 1

    body_text = "Waiting to pair you with someone new"

#    def is_displayed(self):
#        # Check if the current round number exceeds the maximum rounds allowed
#        return self.round_number <= self.session.config['max_rounds']


class Two_Player(Page):
    form_model = 'player'
    form_fields = ['bid']


    @staticmethod
    def js_vars(player: Player):
        return dict(endowment=C.ENDOWMENT)

    def is_displayed(self):
        # Check if the current round number exceeds the maximum rounds allowed
        return self.round_number <= self.session.config['max_rounds']

    def before_next_page(player: Player, timeout_happened):

        participant = player.participant

        # if it's the last round
        if player.round_number == C.NUM_ROUNDS:
            random_round = random.randint(1, C.NUM_ROUNDS)
            participant.selected_round = random_round
            player_in_selected_round = player.in_round(random_round)
            player.final_payoff = player_in_selected_round.payoff
            player.final_payoff_round = random_round


class ResultsWaitPage(WaitPage):
    after_all_players_arrive = set_payoffs

    def is_displayed(self):
        # Check if the current round number exceeds the maximum rounds allowed
        return self.round_number <= self.session.config['max_rounds']

class Results(Page):
    @staticmethod
    def vars_for_template(player: Player):
        opponent = other_player(player)
        return dict(
            opponent=opponent,
            opponent_bid=opponent.bid,
        )
        
    def is_displayed(self):
        # Check if the current round number exceeds the maximum rounds allowed
        return self.round_number <= self.session.config['max_rounds']


page_sequence = [PairingWaitPage, Two_Player, ResultsWaitPage, Results]