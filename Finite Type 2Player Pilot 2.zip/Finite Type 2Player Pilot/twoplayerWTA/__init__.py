from otree.api import (
    models, widgets, BaseConstants, BaseSubsession, BaseGroup, BasePlayer, Page, Currency as c, currency_range, WaitPage
)
import random
import time
from datetime import datetime

doc = """
2 Player Finite-Type Contest Game. Groups players by arrival time for Round 1 and keeps the
matches throughout. Payoffs — a random round — are randomly determined for *the group* after 
the last round.
"""


class C(BaseConstants):
    NAME_IN_URL = 'TwoPlayerWTA'
    PLAYERS_PER_GROUP = 2
    NUM_ROUNDS = 10
    ENDOWMENT = 200
    COST_HIGH = 2
    COST_LOW = 1
    TWO_PLAYER_PRIZE = 100
    SHOWUP_FEE = 2


class Subsession(BaseSubsession):
    pass 

class Group(BaseGroup):
    winning_bid = models.FloatField()
    has_dropout = models.BooleanField(initial=False)



class Player(BasePlayer):

    bid = models.FloatField(
        min=0, max=C.ENDOWMENT, label="How much do you want to bid?"
    )

    is_winner = models.BooleanField()

    final_payoff = models.CurrencyField()

    final_payoff_round = models.IntegerField()

    COST = models.IntegerField()

    is_dropout = models.BooleanField(initial=False)

    played_rounds = models.IntegerField()

    wait_too_long = models.FloatField()

    no_match = models.BooleanField(initial=False)

    no_match_time = models.LongStringField() 

    timedout_code = models.StringField()

    float_payoff = models.FloatField()
    rounded_payoff_shown = models.FloatField()    

    round_start_time = models.LongStringField()
    round_end_time = models.LongStringField()    

# FUNCTIONS

def creating_session(subsession: Subsession): 
    session = subsession.session 

# Assigning costs
    for p in subsession.get_players():
            COST = random.choice([C.COST_HIGH, C.COST_LOW])
            p.COST = COST


# FUNCTIONS

def set_payoffs(group: Group):

    players = group.get_players()
    group.winning_bid = max([p.bid for p in players])
    winners = [p for p in players if p.bid == group.winning_bid]
    winner = random.choice(winners)
    for p in players:
        if p == winner:
            p.is_winner = True
            p.payoff = C.ENDOWMENT + C.TWO_PLAYER_PRIZE - p.bid * p.COST
            p.float_payoff = float(C.ENDOWMENT + C.TWO_PLAYER_PRIZE - p.bid * p.COST)  
            p.rounded_payoff_shown = round(p.float_payoff,2)                
        else:
            p.is_winner = False
            p.payoff = C.ENDOWMENT - p.bid * p.COST
            p.float_payoff = float(C.ENDOWMENT - p.bid * p.COST)
            p.rounded_payoff_shown = round(p.float_payoff,2)                

def other_player(player: Player):
    return player.get_others_in_group()[0] 

def waiting_too_long(player):
    participant = player.participant
    return time.time() - participant.wait_page_arrival > 5 * 60

def group_by_arrival_time_method(subsession, waiting_players):
    if len(waiting_players) >= 2:
        return waiting_players[:2]    

    for player in waiting_players:
        if waiting_too_long(player):
            player.no_match = True
            player.no_match_time = datetime.now().strftime("%H:%M:%S")  
            return [player]


# PAGES

class PairingWaitPage(WaitPage):
    group_by_arrival_time = True
    body_text = "The activity will start as soon as the other player has joined the activity.<br>If another player doesn't show up in 5 minutes, please refresh the page and the game will be canceled.<br>You will receive your participation payment. Please, do not leave this page while waiting.<br><br>To ensure you are connected with another player as soon as possible, you may refresh this page every 30 seconds until you are paired."

    @staticmethod
    def is_displayed(player: Player):
        return player.round_number == 1

    @staticmethod
    def vars_for_template(player: Player):
        import time

class NoMatch(Page):
    def is_displayed(player: Player):
        return player.no_match == True

    def vars_for_template(player: Player):
        return dict(
            showup_fee = C.SHOWUP_FEE
        )        



class Two_Player(Page):
    form_model = 'player'
    form_fields = ['bid']
    def get_timeout_seconds(self):
        if self.round_number == 1:
            return 120
        else:
            return 60

    def vars_for_template(player: Player):
        player.round_start_time = datetime.now().strftime("%H:%M:%S") 

    @staticmethod
    def js_vars(player: Player):
        return dict(endowment=C.ENDOWMENT)

    def is_displayed(self):
        # Check if the current round number exceeds the maximum rounds allowed
        return self.round_number <= self.session.config['max_rounds']

        #If the player times out, their bid is 0 and they get dropped from the experiment.
    @staticmethod
    def before_next_page(player: Player, timeout_happened):
        player.round_end_time = datetime.now().strftime("%H:%M:%S")
        group = player.group
        if timeout_happened:
            group.has_dropout = True
            player.is_dropout = True
            player.bid = 0 

    timer_text = "Time left to click Submit:" 



class ResultsWaitPage(WaitPage):
    after_all_players_arrive = set_payoffs
    body_text = "Waiting for the other player. To minimize your waiting time, you can refresh this page every 15 seconds until you're sent to the next page."

    def is_displayed(self):
        # Check if the current round number exceeds the maximum rounds allowed
        return self.round_number <= self.session.config['max_rounds']

class Results(Page):
    def get_timeout_seconds(self):
        if self.round_number == 1:
            return 60
        else:
            return 30 # should be 30 ultimately

    @staticmethod
    def vars_for_template(player: Player):
        opponent = other_player(player)
        me_in_all_rounds = player.in_all_rounds()
        opponent_in_all_rounds = [other_player(p) for p in me_in_all_rounds]
    
        combined_rounds = [
            {
                'player': p,
                'opponenthist': opponent,
            }
            for p, opponent in zip(me_in_all_rounds, opponent_in_all_rounds)
        ]

        return dict(
            combined_rounds=combined_rounds,
            opponent=opponent,
            opponent_bid=opponent.bid,
            opponent_cost=opponent.COST,
            opponent_payoff=opponent.rounded_payoff_shown,
    )    
    #def vars_for_template(player: Player):
    #    opponent = other_player(player)
    #    return dict(
    #        opponent=opponent,
    #        opponent_bid=opponent.bid,
    #        opponent_cost=opponent.COST,
    #        opponent_payoff=opponent.rounded_payoff_shown,
    #        me_in_all_rounds=player.in_all_rounds(),
    #        opponent_in_all_rounds=opponent.in_all_rounds(),
#
    #    )
        
    def is_displayed(self):
        # Check if the current round number exceeds the maximum rounds allowed
        return self.round_number <= self.session.config['max_rounds']


        # Selecting a random round for group payoffs
    def before_next_page(player: Player, timeout_happened):

        participant = player.participant
        player.played_rounds = player.round_number

        # Get partner
        partner = player.get_others_in_group()[0]
        partner_participant = partner.participant
    
        # if it's the last round
        if player.round_number == C.NUM_ROUNDS:
        
     # Check if 'selected_round' is already set for the partner
            if 'selected_round' in partner_participant.vars:
                selected_round = partner_participant.vars['selected_round']
            else:
                # Select a random round if not set and store it in participant.vars
                selected_round = random.randint(1, player.played_rounds)
                participant.vars['selected_round'] = selected_round
                partner_participant.vars['selected_round'] = selected_round  # Also set for partner to avoid re-randomization
        
     # Retrieve the payoff from the selected round
            player_in_selected_round = player.in_round(selected_round)
            participant.chosen_round_bid = player_in_selected_round.bid
            participant.chosen_round_is_winner = player_in_selected_round.is_winner
            participant.chosen_round_cost = player_in_selected_round.COST
            player.final_payoff = player_in_selected_round.float_payoff
            participant.contest_earnings = player.final_payoff
            participant.payoff = player.final_payoff       
            player.final_payoff_round = selected_round

class DropoutHappened(Page):
    @staticmethod
    def is_displayed(player: Player):
        group = player.group
        return group.has_dropout

    @staticmethod
    def app_after_this_page(player: Player, upcoming_apps):
        return upcoming_apps[0]

    def before_next_page(player: Player, timeout_happened):

        participant = player.participant
        player.played_rounds = player.round_number

                # Get partner
        partner = player.get_others_in_group()[0]
        partner_participant = partner.participant


        # Check if 'selected_round' is already set for the partner
        if 'selected_round' in partner_participant.vars:
            selected_round = partner_participant.vars['selected_round']
        else:
            # Select a random round if not set and store it in participant.vars
            selected_round = random.randint(1, player.played_rounds)
            participant.vars['selected_round'] = selected_round
            partner_participant.vars['selected_round'] = selected_round  # Also set for partner to avoid re-randomization

     # Retrieve the payoff from the selected round
            player_in_selected_round = player.in_round(selected_round)
            participant.chosen_round_bid = player_in_selected_round.bid
            participant.chosen_round_is_winner = player_in_selected_round.is_winner
            participant.chosen_round_cost = player_in_selected_round.COST
            player.final_payoff = player_in_selected_round.float_payoff
            participant.contest_earnings = player.final_payoff
            participant.payoff = player.final_payoff       
            player.final_payoff_round = selected_round

class Drop_Player(Page):
    @staticmethod
    def is_displayed(player: Player):
        return player.is_dropout        

    def vars_for_template(player: Player):
        participant = player.participant
        player.participant.payoff = -2              
        random_digits = ''.join(random.choices('0123456789', k=5))
        player.timedout_code = "TimedOuT" + random_digits    

        return dict(
            code = player.timedout_code)  
          

class Exit_Page(Page):
    def is_displayed(player: Player):
        return player.is_dropout

    def error_message(player: Player, values):
        return "Cannot proceed past this page"  
    



page_sequence = [PairingWaitPage, NoMatch, Two_Player, ResultsWaitPage, Drop_Player, Exit_Page, Results, DropoutHappened]

