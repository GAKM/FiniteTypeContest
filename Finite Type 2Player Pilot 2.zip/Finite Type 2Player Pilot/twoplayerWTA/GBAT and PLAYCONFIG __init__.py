from otree.api import (
    models, widgets, BaseConstants, BaseSubsession, BaseGroup, BasePlayer, Page, Currency as c, currency_range, WaitPage
)
import random

doc = """
2 Player Finite-Type Contest Game
"""


class C(BaseConstants):
    NAME_IN_URL = 'TwoPlayerWTA'
    PLAYERS_PER_GROUP = 2
    NUM_ROUNDS = 15
    ENDOWMENT = 200
    COST_HIGH = 2
    COST_LOW = 1
    SAMPLE_BID = 22
    SAMPLE_BID_2 = 33
    SAMPLE_BIDDING_COST_HIGH = SAMPLE_BID * COST_HIGH
    SAMPLE_BIDDING_COST_LOW = SAMPLE_BID * COST_LOW
    SAMPLE_PRIZE = 100
    TWO_PLAYER_PRIZE = 100
    THREE_PLAYER_WTA_PRIZE = 100
    THREE_PLAYER_LGN_PRIZE_1 = 100
    THREE_PLAYER_LGN_PRIZE_2 = 100
    QUIZ1_CHOICES = ['0', '0.5', '1', 'None of the above']
    QUIZ2_CHOICES = [SAMPLE_BID_2/COST_HIGH, SAMPLE_BID_2 * COST_LOW, str(SAMPLE_BID_2 * COST_HIGH), 'None of the above']
    QUIZ3_CHOICES = ['0 tokens', str(SAMPLE_PRIZE / 2) + ' tokens', str(SAMPLE_PRIZE) + ' tokens', "Depends on my opponent's cost-per-bid"]
    QUIZ4_CHOICES = [str(SAMPLE_PRIZE - SAMPLE_BID_2) + ' tokens', str(ENDOWMENT - SAMPLE_BID_2 * COST_HIGH) + ' tokens', str(ENDOWMENT + SAMPLE_PRIZE - SAMPLE_BID_2 * COST_HIGH) + ' tokens', str(ENDOWMENT + SAMPLE_PRIZE - SAMPLE_BID_2) + ' tokens']


class Subsession(BaseSubsession):
    pass

def creating_session(subsession: Subsession):
    Subsession.past_groups = []


def group_by_arrival_time_method(subsession: Subsession, waiting_players):
    session = subsession.session

    import itertools

    # this generates all possible pairs of waiting players
    # and checks if the group would be valid.
    for possible_group in itertools.combinations(waiting_players, 2):
        # use a set, so that we can easily compare even if order is different
        # e.g. {1, 2} == {2, 1}
        pair_ids = set(p.id_in_subsession for p in possible_group)
        # if this pair of players has not already been played
        if pair_ids not in Subsession.past_groups:
            # mark this group as used, so we don't repeat it in the next round.
            Subsession.past_groups.append(pair_ids)
            # in this function,
            # 'return' means we are creating a new group with this selected pair
            return possible_group    

class Group(BaseGroup):
    winning_bid = models.FloatField()


class Player(BasePlayer):

    bid = models.FloatField(
        min=0, max=C.ENDOWMENT, label="How much do you want to bid?"
    )

    is_winner = models.BooleanField()

#    is_dropout = models.BooleanField(initial=False)



# FUNCTIONS

def set_payoffs(group: Group):

    players = group.get_players()
    group.winning_bid = max([p.bid for p in players])
    winners = [p for p in players if p.bid == group.winning_bid]
    winner = random.choice(winners)
    for p in players:
        if p == winner:
            p.is_winner = True
            p.payoff = C.ENDOWMENT + C.TWO_PLAYER_PRIZE - p.bid * p.participant.COST
        else:
            p.is_winner = False
            p.payoff = C.ENDOWMENT - p.bid * p.participant.COST

def other_player(player: Player):
    return player.get_others_in_group()[0]


# PAGES

class PairingWaitPage(WaitPage):
    group_by_arrival_time = True
    body_text = "Waiting to pair you with someone new"

#    timeout_seconds = 10
#    @staticmethod
#    def before_next_page(player: Player, timeout_happened):
#        # note: bugfix
#        if timeout_happened:
#            player.is_dropout = True


#class ByeDropout(Page):
#    @staticmethod
#    def is_displayed(player: Player):
#        return player.is_dropout
#
#    @staticmethod
#    def error_message(player: Player, values):
#        return "Cannot proceed past this page"

    def is_displayed(self):
        # Check if the current round number exceeds the maximum rounds allowed
        return self.round_number <= self.session.config['max_rounds']


class Two_Player(Page):
    form_model = 'player'
    form_fields = ['bid']


    @staticmethod
    def js_vars(player: Player):
        return dict(endowment=C.ENDOWMENT)

    def is_displayed(self):
        # Check if the current round number exceeds the maximum rounds allowed
        return self.round_number <= self.session.config['max_rounds']

class ResultsWaitPage(WaitPage):
    after_all_players_arrive = set_payoffs

    def is_displayed(self):
        # Check if the current round number exceeds the maximum rounds allowed
        return self.round_number <= self.session.config['max_rounds']

class Results(Page):
    @staticmethod
    def vars_for_template(player: Player):
        opponent = other_player(player)
        return dict(
            opponent=opponent,
            opponent_bid=opponent.bid,
        )
        
    def is_displayed(self):
        # Check if the current round number exceeds the maximum rounds allowed
        return self.round_number <= self.session.config['max_rounds']


page_sequence = [PairingWaitPage, Two_Player, ResultsWaitPage, Results]