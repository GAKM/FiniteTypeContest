from otree.api import *
import random
import time
from datetime import datetime
import string

doc = """
Debrief/ending
"""


class C(BaseConstants):
    NAME_IN_URL = 'Debrief'
    PLAYERS_PER_GROUP = None
    NUM_ROUNDS = 1


class Subsession(BaseSubsession):
    pass


class Group(BaseGroup):
    pass


class Player(BasePlayer):
    experiment_end_time = models.LongStringField()
    completion_code = models.StringField()
    final_bonus_USD = models.FloatField()
    final_payoff_USD = models.FloatField()


# PAGES
class Earnings(Page):
    @staticmethod
    def vars_for_template(player:Player):
        participant = player.participant
        session = player.session
        participant.payoff = float(player.participant.contest_earnings * 0.02)
        player.final_bonus_USD = participant.payoff
        participant.payoff_plus_participation_fee = round(participant.payoff + 2,2)
        player.final_payoff_USD = participant.payoff_plus_participation_fee
        total_payoff_rounded = round(participant.payoff, 2)

        player.experiment_end_time = datetime.now().strftime("%H:%M:%S")        
        characters = string.ascii_letters + string.digits
        player.completion_code = "SSEL_" + ''.join(random.choices(characters, k=10))

        return dict(
            total_bonus = total_payoff_rounded,
            total_earnings_in_USD = participant.payoff_plus_participation_fee,
            code = player.completion_code,
            cost_in_chosen_round = participant.chosen_round_cost,
            bid_in_chosen_round = participant.chosen_round_bid,
            is_winner_in_chosen_round = participant.chosen_round_is_winner,
            )        




page_sequence = [Earnings]
